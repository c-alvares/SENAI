# Atividades
- 1. Normalizar os "dados_brutos" das planilhas de exercício1 à exercício5.
- 2. Fazer o MER_DER conceitual dos bancos de dados normalizados.