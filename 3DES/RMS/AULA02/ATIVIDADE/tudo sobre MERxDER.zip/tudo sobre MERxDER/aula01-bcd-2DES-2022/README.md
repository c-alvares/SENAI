# Tipos de bancos de dados
- Não estruturado
  - TXT
  - DOC
  - PDF
  - XLS (Excel)
- Semi-estruturado
  - XML
  - JSON
- Estruturado
  - CSV
  - Não SQL (Ex: MongoDB, FireBase ...)
    - Não Relacional
  - SQL (Ex: Mysql, Oracle, SQL Server, Postgres, FireBird ...)
    - Relacionais

# MER x DER
- Conceitual
- Lógico
